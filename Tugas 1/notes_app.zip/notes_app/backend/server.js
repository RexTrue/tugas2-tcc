const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

const notesRoutes = require("./routes/notes");

app.use("/api/notes", notesRoutes);

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});